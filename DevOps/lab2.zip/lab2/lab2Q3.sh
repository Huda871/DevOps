#!/bin/bash

file_disp=$1

read=`cat $file_disp`

echo "$read"
